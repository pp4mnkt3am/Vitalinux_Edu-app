import os
from flask import Flask, render_template, request, redirect, url_for, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf','mp4','jpg','jpeg','png','txt','doc','docx','odt'}

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

db = SQLAlchemy(app)

class Alumno(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100))
    grupo = db.Column(db.String(50))

class Asistencia(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    alumno_id = db.Column(db.Integer, db.ForeignKey('alumno.id'))
    fecha = db.Column(db.String(20))
    presente = db.Column(db.Boolean)

class Calificacion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    alumno_id = db.Column(db.Integer, db.ForeignKey('alumno.id'))
    asignatura = db.Column(db.String(50))
    nota = db.Column(db.Float)

class Recurso(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100))
    tipo = db.Column(db.String(20))
    filename = db.Column(db.String(200))

class Cuestionario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    titulo = db.Column(db.String(100))
    pregunta = db.Column(db.String(200))
    respuesta = db.Column(db.String(200))

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/alumnos')
def alumnos():
    lista = Alumno.query.all()
    return render_template('alumnos.html', alumnos=lista)

@app.route('/alumnos/agregar', methods=['POST'])
def agregar_alumno():
    nombre = request.form['nombre']
    grupo = request.form['grupo']
    nuevo = Alumno(nombre=nombre, grupo=grupo)
    db.session.add(nuevo)
    db.session.commit()
    return redirect(url_for('alumnos'))

@app.route('/asistencia')
def asistencia():
    lista = Asistencia.query.all()
    alumnos = Alumno.query.all()
    return render_template('asistencia.html', asistencia=lista, alumnos=alumnos)

@app.route('/asistencia/agregar', methods=['POST'])
def agregar_asistencia():
    alumno_id = request.form['alumno_id']
    fecha = request.form['fecha']
    presente = 'presente' in request.form
    nueva = Asistencia(alumno_id=alumno_id, fecha=fecha, presente=presente)
    db.session.add(nueva)
    db.session.commit()
    return redirect(url_for('asistencia'))

@app.route('/calificaciones')
def calificaciones():
    lista = Calificacion.query.all()
    alumnos = Alumno.query.all()
    return render_template('calificaciones.html', calificaciones=lista, alumnos=alumnos)

@app.route('/calificaciones/agregar', methods=['POST'])
def agregar_calificacion():
    alumno_id = request.form['alumno_id']
    asignatura = request.form['asignatura']
    nota = float(request.form['nota'])
    nueva = Calificacion(alumno_id=alumno_id, asignatura=asignatura, nota=nota)
    db.session.add(nueva)
    db.session.commit()
    return redirect(url_for('calificaciones'))

@app.route('/recursos')
def recursos():
    lista = Recurso.query.all()
    return render_template('recursos.html', recursos=lista)

@app.route('/recursos/agregar', methods=['POST'])
def agregar_recurso():
    titulo = request.form['titulo']
    tipo = request.form['tipo']
    if 'file' not in request.files:
        return redirect(url_for('recursos'))
    file = request.files['file']
    if file.filename == '' or not allowed_file(file.filename):
        return redirect(url_for('recursos'))
    filename = secure_filename(file.filename)
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    nuevo = Recurso(titulo=titulo, tipo=tipo, filename=filename)
    db.session.add(nuevo)
    db.session.commit()
    return redirect(url_for('recursos'))

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/cuestionarios')
def cuestionarios():
    lista = Cuestionario.query.all()
    return render_template('cuestionarios.html', cuestionarios=lista)

@app.route('/cuestionarios/agregar', methods=['POST'])
def agregar_cuestionario():
    titulo = request.form['titulo']
    pregunta = request.form['pregunta']
    respuesta = request.form['respuesta']
    nuevo = Cuestionario(titulo=titulo, pregunta=pregunta, respuesta=respuesta)
    db.session.add(nuevo)
    db.session.commit()
    return redirect(url_for('cuestionarios'))

if __name__ == '__main__':
    if not os.path.exists('database.db'):
        db.create_all()
    app.run(host='0.0.0.0', port=5000, debug=True)
