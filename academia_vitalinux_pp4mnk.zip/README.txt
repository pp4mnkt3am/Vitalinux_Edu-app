Plataforma Académica para Vitalinux (MVP)
Incluye asistencia, alumnos, calificaciones, recursos y cuestionarios.
Autor: pp4mnk
